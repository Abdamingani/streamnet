<?php
if (!defined("ADMINPATH")) {
    exit;
}

echo '
			</div>
		</div>
		<footer>
			<div class="container-fluid">
				<p class="copyright juicycodes">
					Designed With <i class="fa fa-heart heart"></i> by <a href="https://Filmyfy.com">FilmyFy</a>.
				</p>
			</div>
		</footer>
	</div>
</div>
';
$html->GetFooter();
